////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for playing a pattern
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////

#include <string>
#include <fstream>
#include <vector>

#include <iostream>
#include <sstream>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include "portaudio.h"

//2012mar17, spi, begin
/*
#include "WavFile.h"
#include "SoundTouch.h"
using namespace soundtouch;
*/
#define BUFF_SIZE	2048
//2012mar17, spi, end

#include <ctime>
//#include <iostream>
#include "WavSet.h"
#include "Instrument.h"
#include "InstrumentSet.h"

#include <assert.h>
#include <windows.h>
/* Select sample format. */
#if 1
#define PA_SAMPLE_TYPE  paFloat32
typedef float SAMPLE;
#define SAMPLE_SILENCE  (0.0f)
#define PRINTF_S_FORMAT "%.8f"
#elif 1
#define PA_SAMPLE_TYPE  paInt16
typedef short SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#elif 0
#define PA_SAMPLE_TYPE  paInt8
typedef char SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#else
#define PA_SAMPLE_TYPE  paUInt8
typedef unsigned char SAMPLE;
#define SAMPLE_SILENCE  (128)
#define PRINTF_S_FORMAT "%d"
#endif

/* This routine will be called by the PortAudio engine when audio is needed.
** It may called at interrupt level on some machines so don't do anything
** that could mess up the system like calling malloc() or free().
*/
static int patestCallback( const void *inputBuffer, void *outputBuffer,
                           unsigned long framesPerBuffer,
                           const PaStreamCallbackTimeInfo* timeInfo,
                           PaStreamCallbackFlags statusFlags,
                           void *userData )
{
    /* Cast data passed through stream to our structure. */
	WavSet* pWavSet = (WavSet*)userData;//paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned int i;
    (void) inputBuffer; /* Prevent unused variable warning. */

	int idSegmentToPlay = pWavSet->idSegmentSelected+1;
	if(idSegmentToPlay>(pWavSet->numSegments-1)) idSegmentToPlay=0;
#ifdef _DEBUG
	printf("idSegmentToPlay=%d\n",idSegmentToPlay);
#endif //_DEBUG

	assert(pWavSet->numChannels==2);
	for( i=0; i<framesPerBuffer; i++ )
    {
		*out++ = *(pWavSet->GetPointerToSegmentData(idSegmentToPlay)+2*i);  /* left */
		*out++ = *(pWavSet->GetPointerToSegmentData(idSegmentToPlay)+2*i+1);  /* right */
        /*
		// Generate simple sawtooth phaser that ranges between -1.0 and 1.0.
        data->left_phase += 0.01f;
        // When signal reaches top, drop back down. 
        if( data->left_phase >= 1.0f ) data->left_phase -= 2.0f;
        // higher pitch so we can distinguish left and right. 
        data->right_phase += 0.03f;
        if( data->right_phase >= 1.0f ) data->right_phase -= 2.0f;
		*/
    }
	pWavSet->idSegmentSelected = idSegmentToPlay;
    return 0;
}

//////
//main
//////
int main(int argc, char *argv[]);
int main(int argc, char *argv[])
{
    PaStreamParameters outputParameters;
    PaStream* stream;
    PaError err;
	WavSet* pWavSet = NULL;

	///////////////////
	//read in arguments
	///////////////////
	//char charBuffer[2048] = {"."}; //usage: spisplitpatternplay "." 10
	//char charBuffer[2048] = {"testwavfolder"}; //these wav files are all mono
	//char charBuffer[2048] = {"testwavfolder_world"}; //many stereo, many instruments
	char charBuffer[2048] = {"testwavfolder_world2"}; //folder testwavfolder_world subset
	//char charBuffer[2048] = {"testwavfolder_world3"}; //folder testwavfolder_world2 subset

	float fSecondsPlay = 15; //positive for number of seconds to play/loop the pattern
	//double fSecondsPerSegment = 1.0; //non-zero for spliting sample into sub-segments
	double fSecondsPerSegment = 0.0625; //non-zero for spliting sample into sub-segments
	if(argc>1)
	{
		//first argument is the foldername
		sprintf_s(charBuffer,2048-1,argv[1]);
	}
	if(argc>2)
	{
		//second argument is the time it will play
		fSecondsPlay = atof(argv[2]);
	}
	if(argc>3)
	{
		//third argument is the segment length in seconds
		fSecondsPerSegment = atof(argv[3]);
	}

	//////////////////////////////////////////////////
	//populate InstrumentSet according to input folder
	//////////////////////////////////////////////////
	InstrumentSet* pInstrumentSet=new InstrumentSet;
	if(pInstrumentSet)
	{
		pInstrumentSet->Populate(charBuffer);
	}
	else
	{
		assert(false);
		cout << "exiting, instrumentset could not be allocated" << endl;
	}

	////////////////////////
	// initialize port audio 
	////////////////////////
    err = Pa_Initialize();
    if( err != paNoError ) goto error;

	outputParameters.device = Pa_GetDefaultOutputDevice(); // default output device 
	if (outputParameters.device == paNoDevice) 
	{
		fprintf(stderr,"Error: No default output device.\n");
		goto error;
	}
	outputParameters.channelCount = 2;//pWavSet->numChannels;
	outputParameters.sampleFormat =  PA_SAMPLE_TYPE;
	outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;




#define CONCATENATEATTACKS	1

#ifdef _DEBUG //debug: for each instrument, playback the loaded sample files (as is and/or attacks only, i.e. 0.1 sec per sample)
	if(0)
	{
		cout << "number of instruments in this instrumentset = " << pInstrumentSet->instrumentvector.size() << endl;
		//browse through each instrument
		vector<Instrument*>::iterator it;
		for(it=pInstrumentSet->instrumentvector.begin(); it<pInstrumentSet->instrumentvector.end(); it++)
		{
			if(*it!=NULL) 
			{
				Instrument* pInstrument=*it;
				cout << "number of wavset in this instrument = " << pInstrument->wavsetvector.size() << endl;
				WavSet* pWavSet3 = new WavSet; //used with CONCATENATEATTACKS
				//browse through each wavset
				vector<WavSet*>::iterator iterator;
				for(iterator=pInstrument->wavsetvector.begin(); iterator<pInstrument->wavsetvector.end(); iterator++)
				{
					if(*iterator!=NULL) 
					{
						pWavSet=*iterator;
						if(0) 
						{
							/////////////////////////////////////
							// play wavset as is using port audio 
							/////////////////////////////////////
							pWavSet->Play(&outputParameters);
						}

						if(CONCATENATEATTACKS)
						{
							/////////////////////////////////////////////
							//concatenate attacks only (for a later play)
							/////////////////////////////////////////////
							WavSet* pWavSet2 = new WavSet;
							pWavSet2->Copy(pWavSet, 0.2f, 0.0f); //0.2 sec
							pWavSet3->Concatenate(pWavSet2);
							delete pWavSet2;
						}
					}
					else
					{
						assert(false);
					}
				}
				if(CONCATENATEATTACKS)
				{
					//////////////////////////////////////
					// play wavset3 as is using port audio 
					//////////////////////////////////////
					pWavSet3->Play(&outputParameters);
				}
				delete pWavSet3;
			}
			else
			{
				assert(false);
			}
		}

	}
#endif //_DEBUG

	if(1)
	{
		/////////////////////////////////////////////////////////////
		//now, launch each instrument, each playing a default pattern 
		/////////////////////////////////////////////////////////////
		cout << "number of instruments in this instrumentset = " << pInstrumentSet->instrumentvector.size() << endl;
		//browse through each instrument
		vector<Instrument*>::iterator it;
		int i=0;
		for(it=pInstrumentSet->instrumentvector.begin(); it<pInstrumentSet->instrumentvector.end(); it++)
		{
			if(*it!=NULL) 
			{
				Instrument* pInstrument=*it;
				cout << "number of wavset in this instrument = " << pInstrument->wavsetvector.size() << endl;
				WavSet* pWavSet3 = new WavSet; //used with CONCATENATEATTACKS
				//browse through each wavset
				vector<WavSet*>::iterator iterator;
				for(iterator=pInstrument->wavsetvector.begin(); iterator<pInstrument->wavsetvector.end(); iterator++)
				{
					if(*iterator!=NULL) 
					{
						pWavSet=*iterator;
						if(0) 
						{
							/////////////////////////////////////
							// play wavset as is using port audio 
							/////////////////////////////////////
							pWavSet->Play(&outputParameters);
						}

						if(CONCATENATEATTACKS)
						{
							/////////////////////////////////////////////
							//concatenate attacks only (for a later play)
							/////////////////////////////////////////////
							WavSet* pWavSet2 = new WavSet;
							pWavSet2->Copy(pWavSet, 0.2f, 0.0f); //0.2 sec
							pWavSet3->Concatenate(pWavSet2);
							delete pWavSet2;
						}
					}
					else
					{
						assert(false);
					}
				}
				if(CONCATENATEATTACKS)
				{
					//no more than 3 instruments simultaneously
					if(i!=0 && i%3==0)
					{
						//wait for the five tracks to be finished playing
						Sleep((int)fSecondsPlay*1000);
					}

					if(0)
					{
						//////////////////////////////////////
						// play wavset3 as is using port audio 
						//////////////////////////////////////
						pWavSet3->Play(&outputParameters);
					}

					if(0)
					{
						///////////////////////////////
						// play wavset3 as is using sox 
						///////////////////////////////
						i++;
						char charBuffer2[2048];
						char charBuffer3[2048];
						sprintf(charBuffer2, "%d", i);
						string filename="instrument";
						filename = filename + charBuffer2 + ".wav";
						pWavSet3->WriteWavFile(filename.c_str());
						char charBuffer5[10]={"/b"}; //release runs start with /b option which stands for background
						char charBuffer6[10]={"-q"}; //release runs sox.exe with -q option which stands for quiet
						#ifdef _DEBUG
								sprintf_s(charBuffer5,10-1,""); //debug runs start without /b option which stands for background
								sprintf_s(charBuffer6,10-1,""); //debug runs sox.exe without -q option which stands for quiet
						#endif //_DEBUG
						int numRepeat = fSecondsPlay/pWavSet3->GetFileLength();
						sprintf_s(charBuffer3,2048-1,"start %s C:\\sox-14-3-2\\sox %s \"%s\" -d repeat %d",charBuffer5,charBuffer6,filename.c_str(),numRepeat);
						system(charBuffer3);
					}
					if(1)
					{
						///////////////////////////////////
						// play wavset3 as is using spiplay 
						///////////////////////////////////
						i++;
						char charBuffer2[2048];
						char charBuffer3[2048];
						sprintf(charBuffer2, "%d", i);
						string filename="instrument";
						filename = filename + charBuffer2 + ".wav";
						pWavSet3->WriteWavFile(filename.c_str());
						char charBuffer5[10]={"/b"}; //release runs start with /b option which stands for background
						#ifdef _DEBUG
								sprintf_s(charBuffer5,10-1,""); //debug runs start without /b option which stands for background
						#endif //_DEBUG
						sprintf_s(charBuffer3,2048-1,"start %s C:\\spoirier\\oifii-org\\httpdocs\\ns-org\\nsd\\ar\\cp\\audio_spi\\spiplay\\Release\\spiplay.exe \"%s\" %f",charBuffer5,filename.c_str(),fSecondsPlay);
						system(charBuffer3);
					}
				}
				delete pWavSet3;
			}
			else
			{
				assert(false);
			}
		}
	}	

	/////////////////////
	//terminate portaudio
	/////////////////////
	Pa_Terminate();
	if(pInstrumentSet) delete pInstrumentSet;
	//if(pWavSet) delete pWavSet;
	printf("Exiting!\n"); fflush(stdout);
	return 0;
	


error:
    Pa_Terminate();
    fprintf( stderr, "An error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
    return -1;

}

